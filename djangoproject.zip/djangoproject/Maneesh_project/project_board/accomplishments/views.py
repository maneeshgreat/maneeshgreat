from django.http import HttpResponse
from django.shortcuts import render

def accomplishments(request):
    return HttpResponse("This is the accomplishments page and it is done by Django framework done by myself. My accomplishment is creation of many keywords in robot framework.")
