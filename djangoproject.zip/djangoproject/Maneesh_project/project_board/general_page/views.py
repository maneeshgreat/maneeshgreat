from django.http import HttpResponse
from django.shortcuts import render

def general_page(request):
    return HttpResponse("Hello All, This page is the general page of Django framework done by myself")
