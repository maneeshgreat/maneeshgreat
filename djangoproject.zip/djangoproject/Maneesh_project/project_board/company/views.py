from django.http import HttpResponse
from django.shortcuts import render

def company(request):
    return HttpResponse("This is the company page of Django framework done by myself. I work in Mercedes Benz Research and Development India Pvt Ltd")
