from django.http import HttpResponse
from django.shortcuts import render

def hobbies(request):
    return HttpResponse("This is the hobbies page. My hobbies are listening to music and playing PC games.")
