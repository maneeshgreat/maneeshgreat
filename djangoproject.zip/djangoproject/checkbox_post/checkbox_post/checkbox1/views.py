from django.shortcuts import render, redirect


# Create your views here.
def index(request):
    return render(request, 'index.html')


def validate(request):
    if request.method == 'POST':
        hobbies = request.POST.getlist('hobby')
        return render(request, 'validate.html', {'hobbies': hobbies})
    return redirect('index')
