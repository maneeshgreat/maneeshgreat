
from django.shortcuts import render, redirect

from django.http import HttpResponse
from .models import Patient


def patient_entry(request):
    return render(request, 'patient_entry.html')


def process_patient_entry(request):
    if request.method == 'POST':
        patient_name = request.POST.get('patient_name')
        blood_group = request.POST.get('blood_group')

        # Create a new patient entry in the database using the Patient model
        patient = Patient(patient_name=patient_name, blood_group=blood_group)
        patient.save()
        return render(request,'process_patient_entry.html',{'patient_name':patient_name,'blood_group':blood_group})
        return HttpResponse("Data successfully inserted!")
    else:
        return HttpResponse("Invalid request method.")
