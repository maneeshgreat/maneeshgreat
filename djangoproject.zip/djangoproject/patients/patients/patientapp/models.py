from django.db import models

from django.db import models


class Patient(models.Model):
    patient_name = models.CharField(max_length=255)
    blood_group = models.CharField(max_length=10)
