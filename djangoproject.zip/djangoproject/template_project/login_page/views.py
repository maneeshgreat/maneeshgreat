from django.shortcuts import render

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # Dummy check
        if username == 'admin' and password == 'admin123':
            return render(request, 'links.html', {'username': username})
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')

def page1_view(request):
    return render(request, 'page1.html')

def page2_view(request):
    return render(request, 'page2.html')
