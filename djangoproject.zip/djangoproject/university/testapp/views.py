from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def greeting(request):
    s = "<h1>Welcome to first view of testapp</h1><p>This is landing page</p>"
    return HttpResponse(s)

def show_contact(request):
    s = "<h1>Contact Page</h1>"
    s += "<p>Website: mysite.com</p>"
    s += "<p>Mobile: 9000923454</p>"
    s += "<p>Email: mysite@gmail.com</p>"
    return HttpResponse(s)

def about(request):
    s = "<h1>This is for about page</h1>"
    return HttpResponse(s)