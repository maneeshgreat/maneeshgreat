from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.

def show_test(request):
    s = "<h1>This is show Test Page</h1>"
    return HttpResponse(s)

def show_result(request):
    s = "<h1>This is show Result Page</h1>"
    return HttpResponse(s)