from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)
    class_and_section = models.CharField(max_length=100)
    roll = models.CharField(max_length=100)

