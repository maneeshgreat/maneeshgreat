from django.shortcuts import render
from student_data.models import Registration
def student_home(request):
    return render(request, 'student_home.html')

def student_data(request):
    name = request.POST['name']
    class_and_section = request.POST['class_and_section']
    roll = request.POST['roll']
    student_persons = Registration(name=name, class_and_section=class_and_section, roll=roll)
    student_persons.save()
    return render(request, 'student_data.html', {'name':name,'roll':roll})