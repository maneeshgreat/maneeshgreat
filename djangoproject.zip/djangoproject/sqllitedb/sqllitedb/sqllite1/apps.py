from django.apps import AppConfig


class Sqllite1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sqllite1'
