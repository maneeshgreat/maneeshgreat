from django.shortcuts import render

# Create your views here.

from django.shortcuts import render
from sqllite1.models import Registration


def index(request):
    return render(request, 'index.html')


def registered(request):
    first_name = request.POST['fn']
    last_name = request.POST['ln']
    email = request.POST['email']
    password = request.POST['password']

    person = Registration(first_name=first_name, last_name=last_name, email=email, password=password)
    person.save()
    return render(request, 'registered.html', {'fn': first_name})