from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.

def first_company(request):
    s = "<h1>First Company</h1>"
    s += "<p>Name: Renault Nissan Technology and Business Centre India Pvt Ltd</p>"
    s += "<p>Accomplishments: Worked as an engineer in automation engineering involving ECUs</p>"
    return HttpResponse(s)

def second_company(request):
    s = "<h1>Second Company</h1>"
    s += "<p>Name: Capgemini Engineering</p>"
    s += "<p>Accomplishments: Worked as an engineer in Capgemini for client</p>"
    return HttpResponse(s)

def third_company(request):
    s = "<h1>Third Company</h1>"
    s += "<p>Name: Mercedes-Benz Research and Development India</p>"
    s += "<p>Accomplishments: Working as a manual engineer in Variant Coding</p>"
    return HttpResponse(s)