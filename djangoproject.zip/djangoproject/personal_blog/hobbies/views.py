from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.

def first_hobby(request):
    s = "<h1>First Hobby</h1>"
    s += "<p>Name: Cricket</p>"
    s += "<p>Frequency: Rarely</p>"
    return HttpResponse(s)


def second_hobby(request):
    s = "<h1>Second Hobby</h1>"
    s += "<p>Name: Reading Books</p>"
    s += "<p>Frequency: Read many books including facts and crime documentary</p>"
    return HttpResponse(s)


def third_hobby(request):
    s = "<h1>Third Hobby</h1>"
    s += "<p>Name: Playing Games</p>"
    s += "<p>Frequency: Played games from 2010 and 2013</p>"
    return HttpResponse(s)
