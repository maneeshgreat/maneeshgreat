from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.

def tenth(request):
    s = "<h1>10th accomplishments</h1>"
    s += "<p>School: BV, Chennai</p>"
    s += "<p>Accomplishment: Worked as a class leader in 10th</p>"
    return HttpResponse(s)

def twelfth(request):
    s = "<h1>12th Accomplishments</h1>"
    s += "<p>School: Sethu Bhaskara Matric Higher Secondary School</p>"
    s += "<p>Accomplishments: Worked as a class leader and a sports team leader in 12th</p>"
    return HttpResponse(s)

def engineering(request):
    s = "<h1>Engineering Accomplishments</h1>"
    s += "<p>College: S.A. Engineering College</p>"
    s += "<p>Accomplishments: Worked as a team leader in projects involving artificial intelligence</p>"
    return HttpResponse(s)