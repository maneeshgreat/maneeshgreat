from django.http import HttpResponse
from django.shortcuts import render


# Create your views here.

def greetings(request):
    s = "<h1>Welcome to first view of the webpage of myself</h1><p>This is me, Maneesh K</p>"
    return HttpResponse(s)


def contact_details(request):
    s = "<h1>Contact Page</h1>"
    s += "<p>Website: maneesh.com</p>"
    s += "<p>Mobile: 9092336188</p>"
    s += "<p>Email: maneesh6408@gmail.com</p>"
    s += "<p>Company: Mercedes Benz</p>"
    return HttpResponse(s)


def address(request):
    s = "<h2>My Address is:- </h2>"
    s += "<h3>4, Agananuru Street, Annanur</h3>"
    return HttpResponse(s)
