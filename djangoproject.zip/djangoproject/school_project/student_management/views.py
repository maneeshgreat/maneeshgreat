from django.shortcuts import render
from django.views.generic import TemplateView


class HomePageView(TemplateView):
    template_name = 'school_homepage.html'

class DatabaseView(TemplateView):
    template_name = 'student_database/student_data.html'

class LoginView(TemplateView):
    template_name = 'login_page.html'