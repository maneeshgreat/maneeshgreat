from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def dashboard_page(request):
    return HttpResponse("This is a dashboard page!")